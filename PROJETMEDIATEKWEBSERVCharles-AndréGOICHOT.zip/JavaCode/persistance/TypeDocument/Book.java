package JavaCode.persistance.TypeDocument;

import mediatek2022.Utilisateur;
import JavaCode.persistance.TypeDocument.aDoc;
public class Book extends aDoc {
    public Book(String name){
        super(name);
    }

}
