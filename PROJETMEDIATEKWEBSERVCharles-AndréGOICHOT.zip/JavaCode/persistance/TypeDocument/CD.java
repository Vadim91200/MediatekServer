package JavaCode.persistance.TypeDocument;

import mediatek2022.Utilisateur;

public class CD extends aDoc{
    public CD(String name){
        super(name);
    }
}
