package JavaCode.persistance.TypeDocument;

import mediatek2022.Utilisateur;

public class DVD extends aDoc{
    public DVD(String name){
        super(name);
    }
}
