package JavaCode.persistance.PersonalException;

public class DatabaseProblemException extends Exception {
    public DatabaseProblemException(String s){  
        super(s);  
    }  
    
}
